<?php
header('location:views/auth/');