<div class="container">
    <div class="text-center mt-5 pt-5">
        <h1>ANDA BELUM MENDAFTAR</h1>
        <P>Kembali kehalaman pendaftaran untuk mendaftar dan membuat akun untuk emlakukan registrasi calon santri.</P>
    </div>
</div>