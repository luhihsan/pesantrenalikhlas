<div class="container">
    <div class="text-center mt-5 pt-5">
        <h1>DATA ANDA SEDANG DIPROSES</h1>
        <P>Tunggu sebentar, mungkin perlu sedikit waktu untuk memproses data</P>
        <a href="?beranda">kembali ke-beranda</a>
    </div>
</div>