<div class="container">
    <div class="text-center mt-5 pt-5">
        <h1>SATU AKUN HANYA BISA SATU KALI PENDAFTARAN</h1>
        <P>Silahkan registrasi lagi untuk mendaftar menjadi santri</P>
        <a href="?beranda">kembali ke-beranda</a>
    </div>
</div>