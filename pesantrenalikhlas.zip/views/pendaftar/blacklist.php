<div class="container">
    <div class="text-center mt-5 pt-5">
        <h1>MAAF ANDA BELUM DITERIMA</h1>
        <P>Tetap semangat, coba lagi tahun depan</P>
        <a href="?beranda">kembali ke-beranda</a>
    </div>
</div>