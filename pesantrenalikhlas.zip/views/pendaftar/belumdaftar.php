<div class="container">
    <div class="text-center mt-5 pt-5">
        <h1>ANDA BELUM MENDAFTAR</h1>
        <P>Kembali kehalaman pendaftaran untuk mendaftar atau pilih menu pendaftaran</P>
        <a href="?pendaftaranawal">daftar</a>
    </div>
</div>